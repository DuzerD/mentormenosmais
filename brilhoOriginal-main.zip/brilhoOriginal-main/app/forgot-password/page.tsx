import ForgotPasswordPage from "@/components/brilho-original/forgot-password";

export default function ForgotPassword() {
  return <ForgotPasswordPage />
}
