"use client"

import BrilhoOriginalHomepage from "../components/brilho-original/brilho-original-homepage"

export default function Page() {
  return <BrilhoOriginalHomepage />
}
