import LoginPage from "@/components/brilho-original/login-page"

export default function Login() {
  return <LoginPage />
}
